#!/usr/bin/env python

filename = "sequence.txt"

def new_seq():
    tab = [[],[]]
    new = "Y"
    #tab[0] -> temps // tab[1]  ->rapport cyclique
    while(new=="Y"):
        temps = input("Temps en sec = ")
        alpha = input("Rapport cyclique en % = ")
        tab[0].append(temps)
        tab[1].append(alpha)
        new = input("Continue ? (Y/N)")
    return tab

def save_seq(seq):
    with open(filename,'w+') as file:
        for k in range(len(seq[0])):
            file.write("%s;%s\n"%(seq[0][k],seq[1][k]))

def load_seq():
    seq = [[],[]]
    with open(filename,'r') as file:
        for line in file.readlines():
            elem = line.strip("\n").split(";")
            seq[0].append(float(elem[0]))
            seq[1].append(float(elem[1]))
    return seq



if __name__ == "__main__":
    seq = new_seq()
    print(seq)
    save_seq(seq)
    print(load_seq())
