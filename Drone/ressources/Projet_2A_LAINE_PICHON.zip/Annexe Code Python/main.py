#!/usr/bin/env python

import os
  
from read_pwm import reader
import time
import pigpio
import threading
from file_gestion import load_constante,load_seq
from pwm import pwm_gestion
from mpu import*
import threading
import time
import numpy as np
from GPIOInput import pingestion


SAMPLE_TIME = 0.1

class GPIO(threading.Thread):

	def __init__(self):
		super(GPIO,self).__init__()
		constante_tab = load_constante()
		self.seq = load_seq()
		for k in range(len(constante_tab[0])):
			if constante_tab[0][k] == "PWM_GPIO_OUTPUT":
				self.PWM_GPIO_OUTPUT = constante_tab[1][k]
			elif constante_tab[0][k] == "RUN_TIME":
				self.RUN_TIME = constante_tab[1][k]
			elif constante_tab[0][k] == "SAMPLE_TIME":
				#self.SAMPLE_TIME = constante_tab[1][k]
				self.SAMPLE_TIME = SAMPLE_TIME
			elif constante_tab[0][k] == "PWM_GPIO_INPUT":
				self.PWM_GPIO_INPUT = constante_tab[1][k]
			elif constante_tab[0][k] == "PIN_IN":
				self.pin_numb = constante_tab[1][k]

		self.pi = pigpio.pi()
		self.pwm_reader = read_pwm.reader(self.pi,self.PWM_GPIO_INPUT)
		self.PWM_INPUT = [0,0] #Respectivement frequence et rapport cyclique
		self.p = pwm_gestion(self.PWM_GPIO_OUTPUT)
		self.mpu = mpu_gestion()
		self.continu = True
		self.pin = pingestion("water",self.pin_numb,0)
		self.sequence = []


	def apply_sequence(self):

		for elem in np.arange(self.PWM_INPUT[1],self.sequence[0],SAMPLE_TIME):
			time.sleep(SAMPLE_TIME)
			self.p.instant_modification(elem)

		for elem in self.sequence:
			time.sleep(SAMPLE_TIME)
			self.p.instant_modification(elem)

	def start_read_pwm(self):
		self.PWM_INPUT[0] = self.pwm_reader.frequency()
		self.PWM_INPUT[1] = self.pwm_reader.duty_cycle()

	def start_write_pwm(self):
		self.p.instant_modification(self.PWM_INPUT[1])

	def start_read_mpu(self):
		self.mpu.update_all()

	def start_pin(self):
		self.pin.update()

	def water(self):
		if self.pin.state == 1 and len(self.sequence)>1:
			print("Applying seq : ",self.seq)
		elif self.pin.state == 1:
			save_seq_from_controller()

	def save_seq_from_controller(self):
		self.sequence = []
		while self.pin.state == 0:
			self.start_read_pwm()
			time.sleep(SAMPLE_TIME)
			sequence.append(self.PWM_INPUT[1])
			self.start_pin()

	def run(self):
		while self.continu:
			self.start_read_pwm()
			self.start_read_mpu()
			self.start_write_pwm()
			self.water()
			time.sleep(self.SAMPLE_TIME)



if __name__ == "__main__":
	print(load_constante())
	g = GPIO()
	g.start()
	while True:
		time.sleep(SAMPLE_TIME)
		os.system("clear")
		print("Duty cycle = {0:1f}\nmpu = {1:1f}".format(g.PWM_INPUT[1],g.mpu.acceleration[1][0]))
	g.continu = False
