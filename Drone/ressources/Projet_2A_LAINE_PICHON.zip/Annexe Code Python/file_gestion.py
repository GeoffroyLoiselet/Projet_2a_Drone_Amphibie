#!/usr/bin/env python

filename_seq = "sequence.txt"
filename_constante = "GPIO.txt"

def new_seq():
    tab = [[],[]]
    new = "Y"
    #tab[0] -> temps // tab[1]  ->rapport cyclique
    while(new=="Y"):
        temps = input("Temps en sec = ")
        alpha = input("Rapport cyclique en % = ")
        tab[0].append(temps)
        tab[1].append(alpha)
        new = input("Continue ? (Y/N)")
    return tab

def save_seq(seq):
    with open(filename_seq,'w+') as file:
        for k in range(len(seq[0])):
            file.write("%s;%s\n"%(seq[0][k],seq[1][k]))

def load_seq():
    seq = [[],[]]
    with open(filename_seq,'r') as file:
        for line in file.readlines():
            elem = line.strip("\n").split(";")
            seq[0].append(float(elem[0]))
            seq[1].append(float(elem[1]))
    return seq

def load_constante():
    constante = [[],[]]
    with open(filename_constante,"r") as file:
        for line in file.readlines():
            elem = line.strip("\n").split(" ")
            constante[0].append(elem[0])
            constante[1].append(int(elem[1]))
    return constante

def save_seq_from()

if __name__ == "__main__":
    seq = new_seq()
    print(seq)
    save_seq(seq)
    print(load_seq())
    print(load_constante())
