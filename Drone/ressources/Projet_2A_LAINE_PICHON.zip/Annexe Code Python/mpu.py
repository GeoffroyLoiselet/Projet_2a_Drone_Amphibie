#!/usr/bin/env python

from time import sleep
from mpu6050 import mpu6050
import os


#On branche le mpu de la maniere suivante :
#VCC -> 5V
#GND -> GND
#SDA -> GPIO02
#SCL -> GPIO03

adress = 0x68

class mpu_gestion():
    def __init__(self):
        self.sensor = mpu6050(adress)
        self.acceleration = 0
        self.gyroscope = 0
        self.temperature = 0

    def data_to_vector(self,data):
        gyro = [[],[]]
        acc = [[],[]]
    #Extrait les valeurs du gyro, angles comprit entre -10 et 10
        for name,value in data[0].items():
            gyro[0].append(name)
            gyro[1].append(value)
        for name,value in data[1].items():
            acc[0].append(name)
            acc[1].append(value)
        self.gyroscope = gyro
        self.acceleration = acc
        self.temperature = data[2]

    def update_all(self):
        self.data_to_vector(self.sensor.get_all_data())

if __name__ == "__main__":
    mpu = mpu_gestion()
    acc_max = 0
    acc_min = 0
    while True:
        mpu.update_all()
        for elem in mpu.acceleration[1]:
            if elem>acc_max:
                acc_max = elem
            elif elem<acc_min:
                acc_min = elem
        print("Gyro x  = {0:1f}\nacc x = {1:1f}".format(mpu.gyroscope[1][0],mpu.acceleration[1][0]))
