#!/usr/bin/env python

import RPi.GPIO as GPIO
import os
import time
import sys
from def_seq import load_seq

frequence = 50
var_time = 100000


class pwm_gestion():
    def __init__(self,pinout):
        self.pinout = pinout
        self.channel = self.pinout
        GPIO.setwarnings(False)
        GPIO.setmode(GPIO.BCM)
        GPIO.setup(pinout,GPIO.OUT)
        self.p = GPIO.PWM(self.channel,frequence)
        self.alpha = 0
        self.frequence = 100
        self.var_time = 1000000
        self.sequence = load_seq()
        self.p.start(0)

    def no_change():
        return

    def apply_seq(self):
        print(self.sequence)
        self.p.start(0)
        for k in range(len(self.sequence[0])):
            self.p = self.alpha_modification(self.sequence,self.p,k)
            self.p = self.apply_1_seq(self.sequence,self.p,len(self.sequence[1]))
        self.p = self.alpha_modification(self.sequence,self.p,len(self.sequence[1]))
        self.p.stop()

    def apply_1_seq(self,temps,alpha):
        start = time.time
        self.p.ChangeDutyCycle(alpha)
        while(time.time() - start<temps):
             no_change()

    def alpha_modification(self,k=0):
        if k < len(self.sequence[0]):
             if k!=0:
                 alpha = self.sequence[1][k-1]
             else:
                 alpha = 0
             pente =(self.sequence[1][k] - alpha)/self.var_time
             inter = self.sequence[1][k]
        else:
             inter = 0
             alpha = self.sequence[1][k-1]
             pente = (0-self.sequence[1][k-1])/self.var_time

        start = time.time()
        while(not(alpha>inter-0.5 and alpha<inter+0.5)):
             alpha += pente*(time.time() - start)
             self.p.ChangeDutyCycle(alpha)

    def instant_modification(self,alpha):
        self.p.ChangeDutyCycle(alpha)

if __name__ == "__main__":
    print("pwm_gestion : ")
    pwm_object = pwm_gestion()
    pwm_object.instant_modification(50)
