#!/usr/bin/env python

import RPi.GPIO as GPIO
import numpy as np
import os

InputPins = [14]
InputName = ["Avancer_Reculer"]

def initPins():
	pins = []
	for k in range(len(InputName)):
		pins.append(pingestion(InputName[k],InputPins[k],GPIO.IN))
	return pins

def input_pin():
	GPIO.setup(pin,GPIO.IN)
	time.sleep(0.5)
	return GPIO.input(pin)


class pingestion():
	def __init__(self,name,pin,mode):
		GPIO.setmode(GPIO.BCM)
		self.name = name
		self.pin = pin
		self.seq = []
		self.alpha = 0.
		GPIO.setup(pin,mode)

	def update(self):
		self.state = GPIO.input(self.pin)
		return self.state
	"""
	def seq_update(self):
		self.seq = []
		stateBefore = self.update()
		state  = self.update()
		while not(stateBefore==0 and  state==1) :
			stateBefore = state
			state =self.update()
		self.seq.append(1)
		self.seq.append(self.update())
		while not(self.seq[-2]==0 and self.seq[-1]==1):
			self.seq.append(self.update())
		self.alpha =  self.seq.count(1)/len(self.seq)
	"""

if __name__ == "__main__":
	pins = initPins()
	while True:
		pins[0].seq_update()
		print("alpha : ",pins[0].alpha)
